"""Trainer implementations"""

from trainers.base import BaseTrainer

__all__ = ['BaseTrainer']